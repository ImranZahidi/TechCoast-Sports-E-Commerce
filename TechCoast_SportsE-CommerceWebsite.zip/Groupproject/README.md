# TechCoast-Sports-E-Commerce

## Project Name: Sports E-commerce Website

### Description
This is a portfolio website showcasing the work of our team.

### How to Run
1. Extract the files from the ZIP.
2. Open `index.html` in your preferred web browser.
3. Alternatively, host the files on a local server using tools like `Live Server` for optimal results.
